from coffee_machine import CoffeeMachine

if __name__ == "__main__":
    machine = CoffeeMachine()
    machine.run()
